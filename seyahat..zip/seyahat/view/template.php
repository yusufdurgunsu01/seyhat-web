<?php
// Template tüm sayfalar için ortak, landing için farklı başlık ve içerik yapılabilir
$isLanding = basename($view) === 'landing.php';
?>

<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <title>Seyahat Rehberi</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?php if ($isLanding): ?>
    <link rel="stylesheet" href="assets/landing.css">
  <?php else: ?>
    <link rel="stylesheet" href="assets/style.css">
  <?php endif; ?>
</head>
<body style="background: url('view/istanbul.jpg') no-repeat center center fixed; background-size: cover;">
  <?php
    if (file_exists($view)) {
      include $view;
    } else {
      echo "<p>Sayfa bulunamadı.</p>";
    }
  ?>
</body>
</html>

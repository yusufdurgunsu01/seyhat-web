<?php
session_start();

require_once 'controller/AuthController.php';

$action = $_GET['action'] ?? 'landing';
$view = '';

switch ($action) {
  case 'landing':
    $view = 'view/landing.php';
    break;

  case 'login':
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
      (new AuthController())->login($_POST);
      exit;
    }
    $view = 'view/login.php';
    break;

  case 'register':
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
      (new AuthController())->register($_POST);
      exit;
    }
    $view = 'view/register.php';
    break;

  case 'dashboard':
    include 'view/yusuf.php'; // harita.js ile çalışan tam sayfa, template'e sokma
    exit;

  default:
    $view = 'view/landing.php';
    break;
}

// landing hariç tüm sayfalar ortak template ile render edilir
include 'view/template.php';
